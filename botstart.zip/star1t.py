import os
import random
import telegram
from telegram.ext import Updater, CommandHandler, CallbackQueryHandler, MessageHandler, Filters

def start(update, context):
    update.message.reply_text(
        "Hello! I am a Telegram bot. Press the buttons below to control me.",
        reply_markup=telegram.InlineKeyboardMarkup([
            [telegram.InlineKeyboardButton("Instruction", callback_data="1"),
             telegram.InlineKeyboardButton("Raschet", callback_data="2")],
            [telegram.InlineKeyboardButton("Donate", callback_data="3"),
             telegram.InlineKeyboardButton("Support", callback_data="4")]
        ])
    )

def support(update, context):
    query = update.callback_query
    query.edit_message_text(text="@dbalychev")
    query.edit_message_reply_markup(
        reply_markup=telegram.InlineKeyboardMarkup([
            [telegram.InlineKeyboardButton("Back", callback_data="back")]
        ])
    )

def back(update, context):
    query = update.callback_query
    query.edit_message_text(text="Hello! I am a Telegram bot. Press the buttons below to control me.")
    query.edit_message_reply_markup(
        reply_markup=telegram.InlineKeyboardMarkup([
            [telegram.InlineKeyboardButton("Instruction", callback_data="1"),
             telegram.InlineKeyboardButton("Raschet", callback_data="2")],
            [telegram.InlineKeyboardButton("Donate", callback_data="3"),
             telegram.InlineKeyboardButton("Support", callback_data="4")]
        ])
    )

def donate(update, context):
    query = update.callback_query
    query.edit_message_text(text="SBER 9964177300")
    query.edit_message_reply_markup(
        reply_markup=telegram.InlineKeyboardMarkup([
            [telegram.InlineKeyboardButton("Back", callback_data="back")]
        ])
    )
def raschet_start(update, context):
    query = update.callback_query
    query.edit_message_text(text="Please send a message")
    context.user_data['raschet'] = True

def raschet_response(update, context):
    if context.user_data.get('raschet'):
        context.user_data.pop('raschet')
        user_message = update.message.text
        context.user_data['tarologist_answer'] = "Answer as if you were a tarologist: " + user_message
        images_folder = '\\tarororo\ph'
        images = os.listdir(images_folder)
        random_images = random.sample(images, 3)
        for image in random_images:
            with open(f'{images_folder}/{image}', 'rb') as f:
                context.bot.send_photo(chat_id=update.message.chat_id, photo=f)
        context.bot.send_message(chat_id=update.message.chat_id, text="Please enter the name of the maps")
    else:
        save_maps(update, context)



import openai

def save_maps(update, context):
    maps_name = update.message.text
    context.user_data['maps_name'] = maps_name
    merged_message = context.user_data['tarologist_answer'] + " " + context.user_data['maps_name']
    openai.api_key = "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"
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=(f"{merged_message}"),
        max_tokens=2000,
        n=1,
        stop=None,
        temperature=0.5,
    )
    text_response = response["choices"][0]["text"]
    context.bot.send_message(chat_id=update.message.chat_id, text=text_response)





def main():
    # Insert your Telegram bot token here
    token = "5907068279:AAFsiR8jCEeJvZYx3ZKibcNHoafvfMhr5Qo"

    updater = Updater(token, use_context=True)
    dp = updater.dispatcher

    
    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CallbackQueryHandler(support, pattern='4'))
    dp.add_handler(CallbackQueryHandler(donate, pattern='3'))
    dp.add_handler(CallbackQueryHandler(back, pattern='back'))
    dp.add_handler(CallbackQueryHandler(raschet_start, pattern='2'))
    dp.add_handler(MessageHandler(Filters.text, raschet_response))

    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()